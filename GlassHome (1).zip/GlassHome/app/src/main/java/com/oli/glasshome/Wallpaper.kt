package com.oli.glasshome

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/** App-owned wallpaper. Glass panels blur a copy of this, so the blur is real. */
object Wallpaper {
    var bitmap: Bitmap? = null

    fun build(w: Int, h: Int) {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(0xFF1B0A3D.toInt())
        fun blob(cx: Float, cy: Float, r: Float, color: Int) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = RadialGradient(cx, cy, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }
        blob(w * 0.15f, h * 0.10f, w * 1.0f, 0xFFFF6B3D.toInt())
        blob(w * 0.95f, h * 0.35f, w * 0.9f, 0xFF7A3CFF.toInt())
        blob(w * 0.30f, h * 0.65f, w * 0.9f, 0xFFFF3D8B.toInt())
        blob(w * 0.85f, h * 0.95f, w * 0.8f, 0xFF2E6BFF.toInt())
        bitmap = b
    }
}

class WallpaperView(c: Context) : View(c) {
    override fun onDraw(canvas: Canvas) {
        Wallpaper.bitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }
    }
}
