package com.oli.glasshome

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs

class MainActivity : Activity() {

    private lateinit var pm: PackageManager
    private lateinit var prefs: SharedPreferences
    private var all = listOf<AppItem>()

    private lateinit var home: FrameLayout
    private lateinit var drawer: GlassPanel
    private lateinit var search: EditText
    private lateinit var hint: TextView
    private lateinit var homeAdapter: AppAdapter
    private lateinit var drawerAdapter: AppAdapter

    private var drawerOpen = false
    private var screenH = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        pm = packageManager
        prefs = getSharedPreferences("glass", Context.MODE_PRIVATE)

        val bounds = windowManager.currentWindowMetrics.bounds
        screenH = bounds.height()
        Wallpaper.build(bounds.width(), bounds.height())

        loadApps()

        val root = FrameLayout(this)
        root.addView(WallpaperView(this), FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        home = FrameLayout(this)
        root.addView(home, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        home.addView(col, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // --- clock card ---
        val clockCard = GlassPanel(this, dp(30).toFloat())
        val clockCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(14), dp(24), dp(16))
        }
        clockCol.addView(TextClock(this).apply {
            format12Hour = "hh:mm"; format24Hour = "HH:mm"
            textSize = 56f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(6f, 0f, 2f, 0x44000000)
        })
        clockCol.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(0xE6FFFFFF.toInt())
        })
        clockCard.addView(clockCol, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        col.addView(clockCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // --- search bar ---
        val searchBar = GlassPanel(this, dp(26).toFloat())
        searchBar.addView(TextView(this).apply {
            text = "অ্যাপ খুঁজুন"
            textSize = 16f
            setTextColor(0xCCFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), 0, dp(22), 0)
        }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        searchBar.setOnClickListener { openDrawer(true) }
        col.addView(searchBar, LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(14) })

        // --- pinned apps on home ---
        hint = TextView(this).apply {
            text = "অ্যাপ ড্রয়ারে কোনো অ্যাপে লং প্রেস করলে সেটা এখানে পিন হবে"
            textSize = 13f
            setTextColor(0xB3FFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(24), dp(8), 0)
        }
        col.addView(hint, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        homeAdapter = AppAdapter({ launch(it) }, { togglePin(it) })
        val homeList = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = homeAdapter
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(0, dp(12), 0, 0)
            clipToPadding = false
        }
        col.addView(homeList, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // --- dock ---
        col.addView(buildDock(), LinearLayout.LayoutParams(MATCH_PARENT, dp(88)))

        // swipe up on home -> drawer
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -1200f && abs(vy) > abs(vx)) { openDrawer(); return true }
                return false
            }
        })
        home.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }

        // --- drawer ---
        drawer = GlassPanel(this, dp(30).toFloat())
        val drawerCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val handle = FrameLayout(this)
        handle.addView(View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(3).toFloat(); setColor(0x99FFFFFF.toInt())
            }
        }, FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER))
        val closeGd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy > 900f) { closeDrawer(); return true }
                return false
            }
        })
        handle.setOnTouchListener { _, e -> closeGd.onTouchEvent(e); true }
        drawerCol.addView(handle, LinearLayout.LayoutParams(MATCH_PARENT, dp(28)))

        search = EditText(this).apply {
            hint = "অ্যাপ খুঁজুন"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            isSingleLine = true
            setPadding(dp(18), 0, dp(18), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(22).toFloat(); setColor(0x33FFFFFF)
            }
        }
        drawerCol.addView(search, LinearLayout.LayoutParams(MATCH_PARENT, dp(46)).apply {
            leftMargin = dp(16); rightMargin = dp(16); bottomMargin = dp(8)
        })

        drawerAdapter = AppAdapter({ launch(it) }, { togglePin(it) })
        val drawerList = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = drawerAdapter
            clipToPadding = false
            setPadding(dp(8), 0, dp(8), 0)
        }
        drawerCol.addView(drawerList, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        drawer.addView(drawerCol, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        drawer.visibility = View.GONE
        root.addView(drawer, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                drawerAdapter.submit(if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) })
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        root.setOnApplyWindowInsetsListener { _, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            col.setPadding(dp(16), b.top + dp(16), dp(16), b.bottom + dp(12))
            drawerCol.setPadding(0, b.top, 0, b.bottom + dp(4))
            ins
        }

        setContentView(root)
        drawerAdapter.submit(all)
        refreshHome()
    }

    // ---------- apps ----------
    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.loadIcon(pm), it.activityInfo.packageName, it.activityInfo.name) }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(item: AppItem) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(item.pkg, item.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun launchPkg(pkg: String) {
        pm.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun togglePin(item: AppItem) {
        val s = prefs.getStringSet("pins", emptySet())!!.toMutableSet()
        val added = s.add(item.key)
        if (!added) s.remove(item.key)
        prefs.edit().putStringSet("pins", s).apply()
        refreshHome()
        Toast.makeText(this, if (added) "হোমে পিন হয়েছে" else "পিন সরানো হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun refreshHome() {
        val pins = prefs.getStringSet("pins", emptySet())!!
        val list = all.filter { it.key in pins }
        homeAdapter.submit(list)
        hint.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------- dock ----------
    private fun dockPackages(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val found = intents.mapNotNull {
            val p = pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (p == null || p == "android") null else p
        }.distinct()
        return if (found.isNotEmpty()) found.take(4) else all.take(4).map { it.pkg }
    }

    private fun buildDock(): GlassPanel {
        val panel = GlassPanel(this, dp(32).toFloat())
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
        }
        for (pkg in dockPackages()) {
            val iv = ImageView(this)
            try { iv.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (_: Exception) { continue }
            iv.setPadding(dp(6), dp(6), dp(6), dp(6))
            iv.setOnClickListener { launchPkg(pkg) }
            row.addView(iv, LinearLayout.LayoutParams(0, dp(66), 1f))
        }
        panel.addView(row, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return panel
    }

    // ---------- drawer ----------
    private fun openDrawer(focus: Boolean = false) {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = screenH.toFloat()
        drawer.animate().translationY(0f).setDuration(380)
            .setInterpolator(DecelerateInterpolator(2f)).start()
        home.animate().scaleX(0.92f).scaleY(0.92f).alpha(0.5f).setDuration(380).start()
        if (focus) search.postDelayed({
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
        }, 420)
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        search.clearFocus()
        drawer.animate().translationY(screenH.toFloat()).setDuration(300)
            .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }.start()
        home.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(300).start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
        // as a launcher: do nothing on back from home
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) closeDrawer()
    }
}
